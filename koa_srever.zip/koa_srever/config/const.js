const LISTEN = 3000 //定义一些常量  监听端口
const URL = 'http://localhost:' + LISTEN  //请求地址
module.exports = {
    LISTEN,
    URL
}
